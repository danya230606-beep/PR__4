import { EventEmitter } from 'events';
import chalk from 'chalk';

const logger = new EventEmitter();

const colors = {
  info: chalk.greenBright,
  warning: chalk.yellowBright,
  error: chalk.redBright,
};

logger.on('log', ({ level = 'info', message }) => {
  // sv-SE даёт формат YYYY-MM-DD HH:MM:SS
  const time = new Date().toLocaleString('sv-SE');
  const color = colors[level] ?? chalk.white;
  console.log(color(`[${time}] ${level.toUpperCase()}: ${message}`));
});

export default logger;